const express = require("express");
const cors = require("cors");
const sqlite3 = require("sqlite3").verbose();
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const db = new sqlite3.Database("banco.sqlite", (err) => {
  if (err) {
    console.error("Erro ao conectar ao banco:", err.message);
  } else {
    console.log("Conectado ao banco de dados SQLite");
  }
});

app.post("/login", (req, res) => {
  const { email, senha, cpf } = req.body;

  const sql = `
    SELECT * FROM usuarios 
    WHERE (email = ? OR cpf = ?) AND senha = ?
  `;

  db.get(sql, [email, cpf, senha], (err, row) => {
    if (err) {
      console.error(err.message);
      res
        .status(500)
        .json({ sucesso: false, erro: "Erro interno do servidor" });
    } else if (row) {
      res.json({ sucesso: true });
    } else {
      res.json({ sucesso: false });
    }
  });
});

app.listen(PORT, () => {
  console.log(`✅ Servidor rodando em http://localhost:${PORT}`);
});

app.use(cors());
app.use(bodyParser.json());

db.run(`CREATE TABLE IF NOT EXISTS perfil (
  id INTEGER PRIMARY KEY,
  nome TEXT,
  bio TEXT
)`);

db.get("SELECT COUNT(*) as count FROM perfil", (err, row) => {
  if (row.count === 0) {
    db.run("INSERT INTO perfil (nome, bio) VALUES (?, ?)", [
      "Gustavo Henrique",
      "Desenvolvedor Front-End | Góias - GO",
    ]);
  }
});

app.get("/perfil/:id", (req, res) => {
  const id = req.params.id;
  db.get("SELECT * FROM perfil WHERE id = ?", [id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: "Perfil não encontrado" });
    res.json(row);
  });
});

app.put("/perfil/:id", (req, res) => {
  const id = req.params.id;
  const { nome, bio } = req.body;
  db.run(
    "UPDATE perfil SET nome = ?, bio = ? WHERE id = ?",
    [nome, bio, id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Perfil atualizado com sucesso" });
    }
  );
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
