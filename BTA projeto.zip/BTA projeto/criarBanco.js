const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("banco.sqlite");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      senha TEXT NOT NULL,
      cpf TEXT NOT NULL UNIQUE
    )
  `);

  const stmt = db.prepare(
    "INSERT OR IGNORE INTO usuarios (email, senha, cpf) VALUES (?, ?, ?)"
  );

  stmt.run("joao@email.com", "209398847", "111.111.111-11");
  stmt.run("admin@site.com", "admin2025", "222.222.222-22");
  stmt.finalize();

  console.log("✅ Banco criado com sucesso!");
});

db.close();
