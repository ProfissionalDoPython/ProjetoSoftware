function toggleTheme() {
  document.body.classList.toggle("dark-mode");
  const theme = document.body.classList.contains("dark-mode")
    ? "dark"
    : "light";
  localStorage.setItem("theme", theme);
}

window.addEventListener("DOMContentLoaded", () => {
  const theme = localStorage.getItem("theme");
  if (theme === "dark") {
    document.body.classList.add("dark-mode");
  }

  // Fetch and display user data from backend
  fetch('/principal/data') // Fetch from the new endpoint in BancoController
    .then(response => {
      if (!response.ok) {
        // If not authenticated, redirect to login
        if (response.status === 401) {
          window.location.href = '/login';
        }
        throw new Error('Failed to fetch user data');
      }
      return response.json();
    })
    .then(data => {
      // Update the HTML elements with fetched data
      document.getElementById('usuarioNome').textContent = data.usuarioNome || 'Nome do Usuário';
      document.getElementById('usuarioMatricula').textContent = data.usuarioMatricula || 'Matrícula';
    })
    .catch(error => console.error('Error fetching user data:', error));

  const searchInput = document.querySelector('.pesquisa input[type="search"]');
  const cards = document.querySelectorAll(".cards .card");

  searchInput.addEventListener("input", () => {
    const termo = searchInput.value.toLowerCase();

    cards.forEach((card) => {
      const titulo = card.querySelector("h3").textContent.toLowerCase();
      const status = card.textContent.toLowerCase();
      if (titulo.includes(termo) || status.includes(termo)) {
        card.style.display = "flex";
      } else {
        card.style.display = "none";
      }
    });
  });
});

document.addEventListener("DOMContentLoaded", () => {
  const filtroArea = document.getElementById("filtro-area");
  const filtroDestaques = document.getElementById("filtro-destaques");

  const cardsContainer = document.getElementById("cards-container");
  const carrossel = document.getElementById("carrossel");

  const cardsProcessos = cardsContainer.querySelectorAll(".card");
  const cardsDestaque = carrossel.querySelectorAll(".card.destaque");

function aplicarFiltro() {
  const filtroProcessos = filtroArea.value.toLowerCase();
  const filtroDestaque = filtroDestaques.value.toLowerCase();

  cardsProcessos.forEach((card) => {
    const area = card.getAttribute("data-area").toLowerCase();
    const mostrar = filtroProcessos === "" || area === filtroProcessos;
    card.style.display = mostrar ? "" : "none";
  });

  const visiveisProcessos = [...cardsProcessos].filter(card => card.style.display !== "none");

  if (filtroProcessos !== "") {
  cardsContainer.style.display = "flex";
  cardsContainer.style.flexWrap = "wrap";
  cardsContainer.style.justifyContent = visiveisProcessos.length <= 2 ? "center" : "flex-start";
  cardsContainer.style.gap = "48px";
  cardsContainer.style.padding = "20px 0";
  cardsContainer.style.width = "100%";
  cardsContainer.style.overflowX = "hidden";
} else {
  cardsContainer.style.display = "flex";
  cardsContainer.style.flexWrap = "nowrap";
  cardsContainer.style.justifyContent = "flex-start";
  cardsContainer.style.overflowX = "auto";
  cardsContainer.style.gap = "48px";
  cardsContainer.style.padding = "20px 40px";
  cardsContainer.style.width = "auto";
}


  cardsDestaque.forEach((card) => {
    const area = card.getAttribute("data-area").toLowerCase();
    const mostrar = filtroDestaque === "" || area === filtroDestaque;
    card.style.display = mostrar ? "" : "none";
  });

  const visiveisDestaque = [...cardsDestaque].filter(card => card.style.display !== "none");

  carrossel.style.justifyContent =
    filtroDestaque !== "" && visiveisDestaque.length <= 2
      ? "center"
      : "flex-start";
}


  filtroArea.addEventListener("change", aplicarFiltro);
  filtroDestaques.addEventListener("change", aplicarFiltro);

  aplicarFiltro();
});

const statusElements = document.querySelectorAll(".status");

statusElements.forEach((element) => {
  const textoCompleto = element.parentNode.textContent;

const statusMap = {
  "Novidades": {
    color: "#f8f9fa",
    font: "Verdana, Geneva, Tahoma, sans-serif"
  },
  "Recebendo candidaturas": {
    color: "#008000",
    font: "Verdana, Geneva, Tahoma, sans-serif"
  },
  "Eventos Presenciais e Online": {
    color: "#cce5ff",
    font: "Verdana, Geneva, Tahoma, sans-serif"
  },
  "Aguardando inscrições": {
    color: "#FFD700",
    font: "Verdana, Geneva, Tahoma, sans-serif"
  }
};


  for (const statusTexto in statusMap) {
    if (textoCompleto.includes(statusTexto)) {
      const statusNode = element.nextSibling;
      if (statusNode && statusNode.nodeType === Node.TEXT_NODE) {
        const span = document.createElement("span");
        span.textContent = statusTexto;
        span.style.color = statusMap[statusTexto].color;
        span.style.fontFamily = statusMap[statusTexto].font;
        span.style.marginLeft = "4px";

        element.parentNode.replaceChild(span, statusNode);
        element.parentNode.insertBefore(element, span);
        break;
      }
    }
  }
});


function toggleMenu() {
  const menu = document.querySelector(".menu-links");
  menu.classList.toggle("show");
}


function toggleChatbot() {
  const body = document.getElementById("chatbot-body");
  body.style.display = body.style.display === "block" ? "none" : "block";
}

let carrosselOffset = 0;

function moverCarrossel(direcao) {
  const carrossel = document.getElementById("carrossel");
  const cardWidth = 260;
  const gap = 20;
  const totalCardWidth = cardWidth + gap;
  const maxScroll = carrossel.scrollWidth - carrossel.clientWidth;

  carrosselOffset += direcao * totalCardWidth;

  if (carrosselOffset < 0) carrosselOffset = 0;
  if (carrosselOffset > maxScroll) carrosselOffset = maxScroll;

  carrossel.style.transform = `translateX(-${carrosselOffset}px)`;
}

let autoSlideInterval = null;

function iniciarAutoSlide() {
  autoSlideInterval = setInterval(() => {
    const carrossel = document.getElementById("carrossel");
    const cardWidth = 260;
    const gap = 20;
    const totalCardWidth = cardWidth + gap;
    const maxScroll = carrossel.scrollWidth - carrossel.clientWidth;

    carrosselOffset += totalCardWidth;

    if (carrosselOffset > maxScroll) {
      carrosselOffset = 0;
    }

    carrossel.style.transform = `translateX(-${carrosselOffset}px)`;
  }, 10000);
}

window.addEventListener("DOMContentLoaded", () => {
  iniciarAutoSlide();
});


const perguntasFixas = [
  {
    pergunta: "Como me inscrevo em uma vaga?",
    resposta:
      "Acesse a seção 'Processos', clique em 'Ver Detalhes' e siga as instruções na página da vaga.",
  },
  {
    pergunta: "Como atualizo meu perfil?",
    resposta:
      "Clique em 'Perfil' no menu, edite os dados desejados e clique em 'Salvar'.",
  },
  {
    pergunta: "Como saber se fui selecionado?",
    resposta:
      "Você será notificado por e-mail ou poderá acompanhar na área 'Meus Processos'.",
  },
];

function renderizarPerguntas() {
  const container = document.getElementById("faq-list");
  container.innerHTML = "";

  const perguntasSalvas = JSON.parse(localStorage.getItem("faqExtras")) || [];
  const todasPerguntas = [...perguntasFixas, ...perguntasSalvas];

  todasPerguntas.forEach((item, index) => {
    const faqItem = document.createElement("div");
    faqItem.className = "faq-item";

    const isExtra = index >= perguntasFixas.length;

    faqItem.innerHTML = `
      <div class="pergunta" onclick="toggleResposta(this.parentElement)">
        <span class="icone">➕</span> ${item.pergunta}
      </div>
      <p class="resposta">
        ${item.resposta}
        ${
          item.data
            ? `<br><small class="data-hora">📅 ${item.data}</small>`
            : ""
        }
        ${
          isExtra
            ? `<br><button class="remover-btn" onclick="removerPergunta(${
                index - perguntasFixas.length
              })">🗑️ Apagar</button>`
            : ""
        }
      </p>
    `;

    container.appendChild(faqItem);
  });
}

function toggleResposta(item) {
  const todos = document.querySelectorAll(".faq-item");
  todos.forEach((el) => {
    if (el !== item) {
      el.classList.remove("active");
      el.querySelector(".icone").textContent = "➕";
    }
  });

  const ativa = item.classList.contains("active");
  item.classList.toggle("active");
  const icone = item.querySelector(".icone");
  icone.textContent = ativa ? "➕" : "➖";
}

function enviarPergunta(event) {
  event.preventDefault();
  const input = document.getElementById("nova-pergunta");
  const texto = input.value.trim();
  if (texto === "") return;

  const agora = new Date();
  const dataHora = agora.toLocaleString("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  });

  const novaPergunta = {
    pergunta: texto,
    resposta: "Obrigado por sua pergunta! Em breve responderemos.",
    data: dataHora,
  };

  const armazenadas = JSON.parse(localStorage.getItem("faqExtras")) || [];
  armazenadas.push(novaPergunta);
  localStorage.setItem("faqExtras", JSON.stringify(armazenadas));

  fetch("http://localhost:8080/salvar-pergunta", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(novaPergunta),
  })
    .then((res) => res.json())
    .then(() => {
      input.value = "";
      renderizarPerguntas();
    })
    .catch((err) => {
      console.error("Erro ao enviar pergunta:", err);
      renderizarPerguntas();
    });
}

function filtrarPerguntas() {
  const termo = document.getElementById("busca-chatbot").value.toLowerCase();
  const itens = document.querySelectorAll(".faq-item");

  itens.forEach((item) => {
    const pergunta = item.querySelector(".pergunta").textContent.toLowerCase();
    const resposta = item.querySelector(".resposta").textContent.toLowerCase();
    if (pergunta.includes(termo) || resposta.includes(termo)) {
      item.style.display = "block";
    } else {
      item.style.display = "none";
    }
  });
}

window.addEventListener("DOMContentLoaded", () => {
  renderizarPerguntas();
});
function removerPergunta(indice) {
  const armazenadas = JSON.parse(localStorage.getItem("faqExtras")) || [];
  armazenadas.splice(indice, 1);
  localStorage.setItem("faqExtras", JSON.stringify(armazenadas));
  renderizarPerguntas();
}
function scrollCards(direction) {
  const container = document.getElementById("cards-container");
  const cardWidth = container.querySelector(".card")?.offsetWidth || 300;
  container.scrollBy({
    left: direction * (cardWidth + 20),
    behavior: "smooth",
  });
}