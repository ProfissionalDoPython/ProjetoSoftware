function mostrarSenha() {
  const input = document.getElementById("senha");
  const icone = document.getElementById("iconeOlho");

  input.type = input.type === "password" ? "text" : "password";

  if (icone.classList.contains("fa-eye-slash")) {
    icone.classList.remove("fa-eye-slash");
    icone.classList.add("fa-eye");
  } else {
    icone.classList.remove("fa-eye");
    icone.classList.add("fa-eye-slash");
  }
}

function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}

// Function to display the custom alert
function showAlert(message) {
  const customAlert = document.getElementById("customAlert");
  const alertMessage = document.getElementById("alertMessage");
  const closeAlertBtn = document.getElementById("closeAlert");
  // const customAlertOverlay = document.getElementById("customAlertOverlay"); // If you use the overlay

  alertMessage.textContent = message;
  customAlert.style.display = "flex"; // Show the alert box
  // if (customAlertOverlay) customAlertOverlay.style.display = "block"; // Show overlay

  // Close the alert when the OK button is clicked
  closeAlertBtn.onclick = () => {
    customAlert.style.display = "none";
    // if (customAlertOverlay) customAlertOverlay.style.display = "none"; // Hide overlay
  };
}


document
  .getElementById("loginForm")
  .addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value.trim();
    const cpf = document.getElementById("cpf").value.trim();

    if (!email || !senha || !cpf) {
      showAlert("Por favor, preencha todos os campos."); // Use custom alert
      return;
    }

    try {
      const response = await fetch("http://localhost:8080/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha, cpf }),
      });

      const data = await response.json();

      if (data.sucesso) {
        document.getElementById("sucesso").style.display = "flex";
        const duration = 4000;
        const end = Date.now() + duration;
        const defaults = {
          startVelocity: 30,
          spread: 360,
          ticks: 60,
          zIndex: 1000,
        };

        const interval = setInterval(() => {
          if (Date.now() > end) return clearInterval(interval);
          confetti(
            Object.assign({}, defaults, {
              particleCount: 5,
              origin: { x: Math.random(), y: Math.random() - 0.2 },
            })
          );
        }, 200);

        setTimeout(() => {
          window.location.href = "/principal";
        }, 2500);
      } else {
        // Use custom alert for login failure message, displaying the backend's message
        showAlert(data.mensagem || "E-mail, senha ou CPF incorretos.");
      }
    } catch (error) {
      showAlert("Erro ao tentar conectar com o servidor."); // Use custom alert
      console.error(error);
    }
  });

function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute("data-theme") === "dark";
  html.setAttribute("data-theme", isDark ? "light" : "dark");
}