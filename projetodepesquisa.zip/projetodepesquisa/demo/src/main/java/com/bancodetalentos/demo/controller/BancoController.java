// Define o pacote onde este arquivo está localizado.
package com.bancodetalentos.demo.controller;

// Importa os serviços que contêm a lógica de negócio principal da aplicação.
// O Controller delega tarefas complexas a esses serviços.
import com.bancodetalentos.demo.Service.BolsaService;
import com.bancodetalentos.demo.Service.ContasService;
import com.bancodetalentos.demo.Service.PerfilService;
import com.bancodetalentos.demo.Service.EstagioService;
import com.bancodetalentos.demo.Service.EventsService;

// Importa os modelos de dados que representam a estrutura das informações.
import com.bancodetalentos.demo.model.Contas; // Representa as informações de login do usuário.
import com.bancodetalentos.demo.model.Perfis; // Representa os detalhes do perfil do usuário.

// Importa classes do Jakarta Servlet API para lidar com sessões HTTP.
import jakarta.servlet.http.HttpSession;

// Importa anotações e classes do Spring Framework para construir a aplicação web.
import org.springframework.beans.factory.annotation.Autowired; // Para injeção de dependência.
import org.springframework.http.HttpStatus; // Para definir códigos de status HTTP (ex: 200 OK, 401 Unauthorized).
import org.springframework.http.ResponseEntity; // Para construir respostas HTTP personalizadas.
import org.springframework.stereotype.Controller; // Marca esta classe como um Controller Spring MVC.
import org.springframework.ui.Model; // Usado para passar dados do Controller para as views (templates HTML).
import org.springframework.web.bind.annotation.*; // Importa todas as anotações para mapeamento de requisições web.

// Importa classes utilitárias do Java.
import java.util.HashMap; // Para criar mapas (estruturas chave-valor).
import java.util.Map; // Interface para mapas.
import java.util.Optional; // Para lidar com a possibilidade de um valor ser nulo.

/**
 * Controller principal da aplicação "Banco de Talentos".
 * Esta classe é responsável por receber as requisições HTTP dos usuários,
 * processá-las e retornar as respostas adequadas (páginas HTML ou dados JSON).
 * Ele delega a lógica de negócio mais complexa para as classes de serviço.
 */
@Controller // Anotação que indica que esta classe é um componente de controle no Spring MVC.
public class BancoController {

    // Declaração das instâncias dos serviços que este Controller irá utilizar.
    // 'final' garante que essas referências não sejam alteradas após a inicialização.
    private final ContasService contasService;
    private final PerfilService perfilService;
    private final EstagioService estagioService;
    private final BolsaService bolsaService;
    private final EventsService eventsService;

    /**
     * Construtor do BancoController.
     * O Spring, através da anotação @Autowired, injetará automaticamente as instâncias
     * dos serviços necessários quando criar um objeto BancoController.
     * Isso é conhecido como Injeção de Dependência via Construtor, uma boa prática no Spring.
     */
    @Autowired
    public BancoController(ContasService contasService, PerfilService perfilService, EstagioService estagioService,
                           BolsaService bolsaService, EventsService eventsService) {
        this.contasService = contasService;
        this.perfilService = perfilService;
        this.estagioService = estagioService;
        this.bolsaService = bolsaService;
        this.eventsService = eventsService;
    }

    /**
     * Mapeia requisições GET para a raiz ("/") ou para "/inicio".
     * Exibe a página inicial da aplicação.
     * @return O nome do template HTML a ser renderizado (inicio.html).
     */
    @GetMapping({"/", "/inicio"})
    public String mostrarInicio() {
        return "inicio"; // Retorna o nome da view "inicio" (que corresponde a 'src/main/resources/templates/inicio.html').
    }

    /**
     * Mapeia requisições GET para "/login".
     * Exibe o formulário de login.
     * @param model Objeto Model para passar dados para a view.
     * @return O nome do template HTML a ser renderizado (login.html).
     */
    @GetMapping("/login")
    public String mostrarLogin(Model model) {
        // Adiciona um objeto 'Contas' vazio ao modelo.
        // Isso é útil para vincular os campos do formulário HTML a este objeto.
        model.addAttribute("conta", new Contas());
        return "login"; // Retorna o nome da view "login" (login.html).
    }

    /**
     * Mapeia requisições POST para "/login".
     * Processa a tentativa de login do usuário.
     * @param conta Objeto Contas preenchido com as credenciais (CPF, email, senha) enviadas no corpo da requisição.
     * @param session Objeto HttpSession para gerenciar a sessão do usuário.
     * @return ResponseEntity contendo um mapa (JSON) com o status do login e mensagens,
     * e o código de status HTTP apropriado.
     */
    @PostMapping("/login")
    @ResponseBody // Indica que o retorno do método deve ser diretamente o corpo da resposta HTTP (geralmente JSON).
    public ResponseEntity<Map<String, Object>> logar(@RequestBody Contas conta, HttpSession session) {
        // Imprime no console para fins de depuração, mostrando a tentativa de login.
        System.out.println("Tentativa de login: CPF=" + conta.getCpf() + ", Email=" + conta.getEmail() + ", Senha="
                + conta.getSenha());

        // Cria um mapa para armazenar a resposta que será convertida para JSON.
        Map<String, Object> response = new HashMap<>();

        // Chama o serviço para validar as credenciais de login.
        String errorMessage = contasService.validarLogin(conta.getCpf(), conta.getEmail(), conta.getSenha());

        if (errorMessage == null) { // Se a validação inicial não encontrou erros (credenciais formatadas corretamente).
            // Tenta obter a conta completa e validada do serviço.
            Optional<Contas> contaValidada = contasService.getValidAccount(conta.getCpf(), conta.getEmail(), conta.getSenha());

            if (contaValidada.isPresent()) { // Se a conta foi encontrada e as credenciais estão corretas.
                Contas usuarioLogado = contaValidada.get(); // Obtém o objeto Contas do Optional.

                // Armazena informações essenciais do usuário na sessão HTTP.
                // Isso permite que essas informações sejam acessadas em outras requisições do usuário logado.
                session.setAttribute("usuarioLogadoCpf", usuarioLogado.getCpf());
                session.setAttribute("usuarioLogadoEmail", usuarioLogado.getEmail());
                session.setAttribute("tipoPerfil", usuarioLogado.getTipoPerfil());

                // Busca o perfil do usuário para obter o nome, que será exibido na interface.
                Optional<Perfis> perfilUsuario = perfilService.buscarPerfilPorCpf(usuarioLogado.getCpf());
                if (perfilUsuario.isPresent()) {
                    session.setAttribute("usuarioNome", perfilUsuario.get().getNome());
                    session.setAttribute("usuarioMatricula", "N/A"); // Define a matrícula como "N/A" se não houver no perfil.
                } else {
                    // Se o perfil não for encontrado, define um nome e matrícula padrão.
                    session.setAttribute("usuarioNome", "Usuário");
                    session.setAttribute("usuarioMatricula", "N/A");
                }

                // Preenche o mapa de resposta com informações de sucesso.
                response.put("sucesso", true);
                response.put("mensagem", "Login realizado com sucesso!");
                response.put("tipoPerfil", usuarioLogado.getTipoPerfil());

                System.out.println("Login bem-sucedido para: " + usuarioLogado.getEmail() + " (Tipo: " + usuarioLogado.getTipoPerfil() + ")");

                // Retorna uma resposta HTTP 200 OK (sucesso) com o mapa de resposta.
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else { // Este bloco geralmente não é atingido se validarLogin() já retornou null,
                     // mas é uma salvaguarda para erros inesperados na obtenção da conta.
                response.put("sucesso", false);
                response.put("mensagem", "Erro interno no servidor ao processar o login.");
                // Retorna um status HTTP 500 (Erro Interno do Servidor).
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else { // Se houver uma mensagem de erro da validação inicial (credenciais inválidas, etc.).
            // Preenche o mapa de resposta com informações de falha.
            response.put("sucesso", false);
            response.put("mensagem", errorMessage); // A mensagem de erro específica é retornada.

            System.out.println("Falha no login para: " + conta.getEmail() + " - " + errorMessage);

            // Retorna um status HTTP 401 (Não Autorizado) com a mensagem de erro.
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * Mapeia requisições GET para "/principal".
     * Exibe a página principal da aplicação após o login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @param model Objeto Model para passar dados para a view.
     * @return O nome do template HTML a ser renderizado (principal.html) ou um redirecionamento para o login.
     */
    @GetMapping("/principal")
    public String mostrarPaginaPrincipal(HttpSession session, Model model) {
        // Obtém informações do usuário da sessão.
        String tipoPerfil = (String) session.getAttribute("tipoPerfil");
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        String usuarioNome = (String) session.getAttribute("usuarioNome");
        String usuarioMatricula = (String) session.getAttribute("usuarioMatricula");

        // Verifica se o usuário está logado. Se não, redireciona para a página de login.
        if (tipoPerfil == null || usuarioCpf == null) {
            return "redirect:/login"; // Redireciona o navegador do cliente.
        }

        // Adiciona os atributos do usuário ao modelo para que possam ser exibidos na página principal.
        model.addAttribute("tipoPerfil", tipoPerfil);
        model.addAttribute("usuarioCpf", usuarioCpf);
        model.addAttribute("usuarioNome", usuarioNome != null ? usuarioNome : "Nome do Usuário");
        model.addAttribute("usuarioMatricula", usuarioMatricula != null ? usuarioMatricula : "Matrícula");
        return "principal"; // Retorna o nome da view "principal" (principal.html).
    }

    /**
     * Mapeia requisições GET para "/eventos".
     * Exibe a página de eventos, protegida por login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @return O nome do template HTML (eventos.html) ou um redirecionamento para o login.
     */
    @GetMapping("/eventos")
    public String mostrarPaginaEventos(HttpSession session) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login"; // Redireciona se o usuário não estiver logado.
        }
        return "eventos"; // Retorna o nome da view "eventos".
    }

    /**
     * Mapeia requisições GET para "/transparencia".
     * Exibe a página de transparência, protegida por login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @return O nome do template HTML (transparencia.html) ou um redirecionamento para o login.
     */
    @GetMapping("/transparencia")
    public String mostrarPaginaTransparencia(HttpSession session) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login";
        }
        return "transparencia";
    }

    /**
     * Mapeia requisições GET para "/processos".
     * Exibe a página de processos, protegida por login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @return O nome do template HTML (processos.html) ou um redirecionamento para o login.
     */
    @GetMapping("/processos")
    public String mostrarPaginaProcessos(HttpSession session) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login";
        }
        return "processos";
    }

    /**
     * Mapeia requisições GET para "/estagios".
     * Exibe a página de estágios, protegida por login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @return O nome do template HTML (estagios.html) ou um redirecionamento para o login.
     */
    @GetMapping("/estagios")
    public String mostrarPaginaEstagios(HttpSession session) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login";
        }
        return "estagios";
    }

    /**
     * Mapeia requisições GET para "/bolsas".
     * Exibe a página de bolsas, protegida por login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @return O nome do template HTML (bolsas.html) ou um redirecionamento para o login.
     */
    @GetMapping("/bolsas")
    public String mostrarPaginaBolsas(HttpSession session) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login";
        }
        return "bolsas";
    }

    /**
     * Mapeia requisições GET para "/events".
     * Exibe a página de eventos, protegida por login.
     * @param session Objeto HttpSession para verificar o status de login.
     * @return O nome do template HTML (events.html) ou um redirecionamento para o login.
     */
    @GetMapping("/events")
    public String mostrarPaginaEvents(HttpSession session) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login";
        }
        return "events";
    }

    /**
     * Mapeia requisições GET para "/inscricoes".
     * Exibe a página de gerenciamento de inscrições. Esta página é restrita apenas a usuários "administrador".
     * @param session Objeto HttpSession para verificar o status de login e o tipo de perfil.
     * @return O nome do template HTML (inscricoes.html) ou um redirecionamento para o login.
     */
    @GetMapping("/inscricoes")
    public String mostrarPaginaInscricoes(HttpSession session) {
        String tipoPerfil = (String) session.getAttribute("tipoPerfil");
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");

        // Permite acesso SOMENTE se o usuário estiver logado E for um administrador.
        if (usuarioCpf == null || !"administrador".equals(tipoPerfil)) {
            // Em uma aplicação real, você poderia redirecionar para uma página de "Acesso Negado" (403 Forbidden).
            return "redirect:/login"; // Por enquanto, redireciona para o login.
        }
        return "inscricoes"; // Retorna o nome da view "inscricoes".
    }

    /**
     * Mapeia requisições GET para "/inscricao".
     * Exibe uma página de inscrição individual, protegida por login.
     * Pode opcionalmente receber um parâmetro 'titulo' via URL (ex: /inscricao?titulo=EventoX).
     * @param session Objeto HttpSession para verificar o status de login.
     * @param titulo Parâmetro opcional da URL para o título da inscrição.
     * @param model Objeto Model para passar dados para a view (não utilizado com 'titulo' neste exemplo, mas disponível).
     * @return O nome do template HTML (inscricao.html) ou um redirecionamento para o login.
     */
    @GetMapping("/inscricao")
    public String mostrarPaginaInscricao(HttpSession session, @RequestParam(name = "titulo", required = false) String titulo, Model model) {
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");
        if (usuarioCpf == null) {
            return "redirect:/login";
        }
        // O parâmetro 'titulo' é recebido, mas não é adicionado ao modelo ou utilizado neste método no momento.
        return "inscricao";
    }

    /**
     * Mapeia requisições GET para "/principal/data".
     * Fornece dados do usuário logado (nome, matrícula) em formato JSON.
     * Este endpoint é tipicamente acessado por JavaScript (AJAX) na página principal
     * para carregar informações dinamicamente.
     * @param session Objeto HttpSession para obter os dados do usuário.
     * @return ResponseEntity contendo um mapa (JSON) com os dados do usuário e o código de status HTTP.
     */
    @GetMapping("/principal/data")
    @ResponseBody // Indica que o retorno é o corpo da resposta HTTP, não um nome de view.
    public ResponseEntity<Map<String, String>> getPrincipalData(HttpSession session) {
        Map<String, String> data = new HashMap<>(); // Cria um mapa para os dados que serão convertidos para JSON.
        String usuarioNome = (String) session.getAttribute("usuarioNome");
        String usuarioMatricula = (String) session.getAttribute("usuarioMatricula");
        String usuarioCpf = (String) session.getAttribute("usuarioLogadoCpf");

        // Se o usuário não estiver logado, retorna um status 401 Unauthorized.
        if (usuarioCpf == null) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        // Adiciona os dados do usuário ao mapa. Se forem nulos na sessão, define valores padrão.
        data.put("usuarioNome", usuarioNome != null ? usuarioNome : "Nome do Usuário");
        data.put("usuarioMatricula", usuarioMatricula != null ? usuarioMatricula : "N/A");
        // Retorna um status 200 OK com os dados do usuário no corpo da resposta.
        return new ResponseEntity<>(data, HttpStatus.OK);
    }

    /**
     * Mapeia requisições GET para "/logout".
     * Realiza o processo de logout do usuário.
     * @param session Objeto HttpSession a ser invalidado.
     * @return Um redirecionamento para a página de login.
     */
    @GetMapping("/logout")
    public String fazerLogout(HttpSession session) {
        session.invalidate(); // Invalida (encerra) a sessão HTTP, removendo todos os atributos do usuário.
        return "redirect:/login"; // Redireciona o usuário para a página de login.
    }
}