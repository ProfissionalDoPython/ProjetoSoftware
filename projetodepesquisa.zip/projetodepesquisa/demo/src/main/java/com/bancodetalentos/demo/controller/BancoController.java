package com.bancodetalentos.demo.controller;

import com.bancodetalentos.demo.Service.ContasService;
import com.bancodetalentos.demo.model.Contas;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

// meu controller que lida com as requisições relacionadas ao banco de talentos
@Controller
public class BancoController {

    private final ContasService contasService;

    // injeção de dependência do serviço ContasService
    @Autowired
    public BancoController(ContasService contasService) {
        this.contasService = contasService;
    }

    // metodo para exibir a página de login
    @GetMapping("/login")
    public String mostrarLogin(Model model) {
        model.addAttribute("conta", new Contas());
        return "login";
    }

    // metodo para processar o login, recebendo os dados da conta e validando
    @PostMapping("/login")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> logar(@RequestBody Contas conta, HttpSession session) {
        System.out.println("Tentativa de login: CPF=" + conta.getCpf() + ", Email=" + conta.getEmail() + ", Senha="
                + conta.getSenha());

        Map<String, Object> response = new HashMap<>();

        // primeiro, tente validar o login e obter a mensagem de erro específica
        String errorMessage = contasService.validarLogin(conta.getCpf(), conta.getEmail(), conta.getSenha());

        if (errorMessage == null) { // login bem-sucedido
            // agora, obtenha o objeto Contas completo para armazenar na sessão
            Optional<Contas> contaValidada = contasService.getValidAccount(conta.getCpf(), conta.getEmail(), conta.getSenha());
            if (contaValidada.isPresent()) {
                Contas usuarioLogado = contaValidada.get();
                session.setAttribute("usuarioLogadoCpf", usuarioLogado.getCpf());
                session.setAttribute("usuarioLogadoEmail", usuarioLogado.getEmail());
                session.setAttribute("tipoPerfil", usuarioLogado.getTipoPerfil());
                response.put("sucesso", true);
                response.put("mensagem", "Login realizado com sucesso!");
                response.put("tipoPerfil", usuarioLogado.getTipoPerfil());
                System.out.println("Login bem-sucedido para: " + usuarioLogado.getEmail() + " (Tipo: " + usuarioLogado.getTipoPerfil() + ")");
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // se não encontrou a conta, retorne um erro interno
                response.put("sucesso", false);
                response.put("mensagem", "Erro interno no servidor ao processar o login.");
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else { // login falhou, use a mensagem específica
            response.put("sucesso", false);
            response.put("mensagem", errorMessage); // mensagem de erro específica
            System.out.println("Falha no login para: " + conta.getEmail() + " - " + errorMessage);
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED); // vai dar 401 Unauthorized
        }
    }

    // metodo para exibir a página principal, verificando o tipo de perfil do usuário
    @GetMapping("/principal")
    public String mostrarPaginaPrincipal(HttpSession session, Model model) {
        String tipoPerfil = (String) session.getAttribute("tipoPerfil");
        if (tipoPerfil == null) {
            return "redirect:/login";
        }
        model.addAttribute("tipoPerfil", tipoPerfil);
        return "principal";
    }

    // uso isso para fazer o logout do usuário, invalidando a sessão
    @GetMapping("/logout")
    public String fazerLogout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}