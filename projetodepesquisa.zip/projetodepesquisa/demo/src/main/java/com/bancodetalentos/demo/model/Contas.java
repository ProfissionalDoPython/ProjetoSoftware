package com.bancodetalentos.demo.model;

/**
 * Classe de modelo que representa uma conta de usuário no sistema.
 * Contém informações básicas de autenticação como senha, e-mail, CPF e tipo de perfil.
 * É usada para mapear os dados do arquivo JSON e para a lógica de login.
 */
public class Contas {
    private String senha; // Senha do usuário.
    private String email; // E-mail do usuário, usado para login.
    private String cpf; // CPF do usuário, usado como identificador único e para login.
    private String tipoPerfil; // Tipo de perfil do usuário (ex: "administrador", "aluno", "professor", "recrutador").

    /**
     * Construtor padrão vazio.
     * Essencial para o Spring e para o Gson ao criar instâncias da classe.
     */
    public Contas() {
        // Construtor padrão vazio, importante para o Spring e Gson.
    }

    /**
     * Construtor completo para inicializar todos os campos da classe Contas.
     *
     * @param senha A senha do usuário.
     * @param email O e-mail do usuário.
     * @param cpf O CPF do usuário.
     * @param tipoPerfil O tipo de perfil do usuário.
     */
    public Contas(String senha, String email, String cpf, String tipoPerfil) {
        this.senha = senha;
        this.email = email;
        this.cpf = cpf;
        this.tipoPerfil = tipoPerfil;
    }

    // A seguir, os métodos Getters e Setters para cada atributo da classe.

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTipoPerfil() {
        return tipoPerfil;
    }

    public void setTipoPerfil(String tipoPerfil) {
        this.tipoPerfil = tipoPerfil;
    }

    /**
     * Método para verificar se a senha fornecida corresponde à senha armazenada nesta conta.
     *
     * @param senhaDigitada A senha digitada pelo usuário no formulário de login.
     * @return {@code true} se as senhas coincidirem e a senha armazenada não for nula, {@code false} caso contrário.
     */
    public boolean verificarSenha(String senhaDigitada) {
        return this.senha != null && this.senha.equals(senhaDigitada);
    }
}