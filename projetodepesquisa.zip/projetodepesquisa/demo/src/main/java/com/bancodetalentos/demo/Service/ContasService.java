package com.bancodetalentos.demo.Service;

import com.bancodetalentos.demo.model.Contas; // Importa a classe de modelo Contas.
import com.google.gson.Gson; // Importa a biblioteca Gson para manipulação de JSON.
import com.google.gson.reflect.TypeToken; // Importa TypeToken para lidar com tipos genéricos em Gson.

import org.springframework.beans.factory.annotation.Value; // Importa @Value para injetar valores de propriedades.
import org.springframework.stereotype.Service; // Anotação do Spring que marca esta classe como um serviço.

import java.io.File; // Para manipulação de arquivos no sistema de arquivos.
import java.io.FileReader; // Para ler arquivos.
import java.io.IOException; // Para tratamento de exceções de I/O.
import java.lang.reflect.Type; // Para obter o tipo genérico para desserialização com Gson.
import java.util.ArrayList; // Para usar ArrayLists.
import java.util.List; // Para usar Lists.
import java.util.Optional; // Para retornar valores que podem ou não estar presentes.

/**
 * Este serviço lida com a lógica de negócios relacionada às contas dos usuários.
 * Inclui validação de login e carregamento de dados de contas de um arquivo JSON.
 */
@Service // Indica ao Spring que esta é uma classe de serviço e deve ser gerenciada pelo contêiner Spring.
public class ContasService {

    // Define o caminho para o arquivo JSON onde as contas dos usuários estão armazenadas.
    // O valor é injetado do `application.properties` (ex: app.json.usuario-path=./jsonpasta/usuario.json).
    @Value("${app.json.usuario-path}")
    private String JSON_FILE_PATH;

    // Instância da biblioteca Gson, utilizada para serializar e desserializar os dados das contas.
    private final Gson gson = new Gson();

    /**
     * Carrega a lista de contas a partir do arquivo JSON especificado.
     * Este método é privado porque é um método auxiliar interno do serviço.
     *
     * @return Uma lista de objetos {@link Contas} carregados do JSON,
     * ou uma lista vazia se o arquivo não for encontrado ou houver erro na leitura.
     */
    private List<Contas> carregarContasDoJson() {
        try {
            // Cria um objeto File representando o caminho do arquivo JSON no sistema de arquivos.
            File file = new File(JSON_FILE_PATH);
            // Verifica se o arquivo existe antes de tentar ler.
            if (!file.exists()) {
                System.err.println("Arquivo de usuário não encontrado no caminho: " + JSON_FILE_PATH);
                // Retorna uma lista vazia se o arquivo não existir.
                return new ArrayList<>();
            }
            // Cria um FileReader para ler o conteúdo do arquivo.
            FileReader reader = new FileReader(file);
            // Define o tipo genérico para a desserialização (lista de Contas).
            Type listType = new TypeToken<ArrayList<Contas>>(){}.getType();
            // Desserializa o JSON lido pelo reader para uma lista de objetos Contas.
            List<Contas> contas = gson.fromJson(reader, listType);
            // Fecha o leitor para liberar recursos.
            reader.close();
            // Retorna a lista de contas se não for nula, caso contrário, retorna uma nova ArrayList vazia.
            return contas != null ? contas : new ArrayList<>();
        } catch (IOException e) {
            // Captura exceções de I/O (ex: arquivo não encontrado, permissão negada).
            System.err.println("Erro ao carregar contas do JSON: " + e.getMessage());
            e.printStackTrace(); // Imprime o stack trace para depuração.
            return new ArrayList<>(); // Em caso de erro, retorna uma lista vazia.
        }
    }

    /**
     * Valida as credenciais de login (CPF, e-mail e senha) fornecidas pelo usuário.
     * Percorre a lista de contas carregadas do JSON para encontrar uma correspondência.
     *
     * @param cpf O CPF fornecido para login.
     * @param email O e-mail fornecido para login.
     * @param senha A senha fornecida para login.
     * @return Uma String contendo uma mensagem de erro específica se o login falhar,
     * ou {@code null} se o login for bem-sucedido.
     */
    public String validarLogin(String cpf, String email, String senha) {
        // Carrega todas as contas existentes do arquivo JSON.
        List<Contas> contas = carregarContasDoJson();

        // Linhas de depuração para exibir os dados recebidos no serviço (útil em desenvolvimento).
        System.out.println("Dados recebidos no ContasService:");
        System.out.println("CPF recebido: " + cpf);
        System.out.println("Email recebido: " + email);
        System.out.println("Senha recebida: " + senha);

        Optional<Contas> foundAccount = Optional.empty(); // Variável para armazenar a conta encontrada.
        boolean cpfExists = false; // Flag para verificar se o CPF existe.
        boolean emailExists = false; // Flag para verificar se o e-mail existe.

        // Itera sobre cada conta na lista para encontrar uma correspondência.
        for (Contas conta : contas) {
            if (conta.getCpf().equals(cpf)) {
                cpfExists = true; // CPF encontrado.
            }
            if (conta.getEmail().equalsIgnoreCase(email)) {
                emailExists = true; // E-mail encontrado (ignorando caixa).
            }

            // Verifica se CPF, e-mail e senha correspondem a uma conta válida.
            if (conta.getCpf().equals(cpf) &&
                conta.getEmail().equalsIgnoreCase(email) &&
                conta.verificarSenha(senha)) {
                foundAccount = Optional.of(conta); // Armazena a conta válida.
                break; // Sai do loop.
            }
        }

        if (foundAccount.isPresent()) {
            return null; // Login bem-sucedido.
        } else {
            // Retorna mensagens de erro específicas.
            if (!cpfExists) {
                return "CPF não encontrado.";
            } else if (!emailExists) {
                return "E-mail ou CPF inválidos.";
            } else {
                return "Senha incorreta.";
            }
        }
    }

    /**
     * Retorna o objeto {@link Contas} validado, se o login for bem-sucedido.
     * Este método complementa {@code validarLogin} focando na recuperação do objeto.
     *
     * @param cpf O CPF do usuário.
     * @param email O e-mail do usuário.
     * @param senha A senha do usuário.
     * @return Um {@link Optional} contendo o objeto {@link Contas} se encontrado e validado,
     * ou um {@link Optional#empty()} caso contrário.
     */
    public Optional<Contas> getValidAccount(String cpf, String email, String senha) {
        List<Contas> contas = carregarContasDoJson(); // Carrega as contas.
        for (Contas conta : contas) { // Itera para encontrar a correspondência exata.
            if (conta.getCpf().equals(cpf) &&
                conta.getEmail().equalsIgnoreCase(email) &&
                conta.verificarSenha(senha)) {
                return Optional.of(conta); // Retorna a conta encontrada.
            }
        }
        return Optional.empty(); // Conta não encontrada.
    }
}