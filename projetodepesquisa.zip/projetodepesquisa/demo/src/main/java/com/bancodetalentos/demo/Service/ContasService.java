package com.bancodetalentos.demo.Service;

import com.bancodetalentos.demo.model.Contas;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// esse e o serviço que lida com as contas, como validação de login e carregamento de dados do JSON
@Service
public class ContasService {

    private final String JSON_FILE_PATH = "jsonpasta/usuario.json";
    private final Gson gson = new Gson();

    // metodo para carregar as contas do arquivo JSON
    private List<Contas> carregarContasDoJson() {
        try {
            File file = new File(JSON_FILE_PATH);
            FileReader reader = new FileReader(file);
            Type listType = new TypeToken<ArrayList<Contas>>(){}.getType();
            List<Contas> contas = gson.fromJson(reader, listType);
            reader.close();
            return contas != null ? contas : new ArrayList<>();
        } catch (IOException e) {
            System.err.println("Erro ao carregar contas do JSON: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // altere o retorno para String, que será a mensagem de erro, ou null se sucesso.
    public String validarLogin(String cpf, String email, String senha) {
        List<Contas> contas = carregarContasDoJson();

        System.out.println("Dados recebidos no ContasService:");
        System.out.println("CPF recebido: " + cpf);
        System.out.println("Email recebido: " + email);
        System.out.println("Senha recebida: " + senha);

        Optional<Contas> foundAccount = Optional.empty();
        boolean cpfExists = false;
        boolean emailExists = false;

        for (Contas conta : contas) {
            if (conta.getCpf().equals(cpf)) {
                cpfExists = true;
            }
            if (conta.getEmail().equalsIgnoreCase(email)) {
                emailExists = true;
            }

            if (conta.getCpf().equals(cpf) &&
                conta.getEmail().equalsIgnoreCase(email) &&
                conta.verificarSenha(senha)) {
                foundAccount = Optional.of(conta);
                break; // encontrou a conta, sai do loop
            }
        }

        if (foundAccount.isPresent()) {
            return null; // login bem-sucedido, retorna null para indicar sucesso
        } else {
            // se não encontrou a conta, verifica quais campos estão incorretos
            if (!cpfExists) {
                return "CPF não encontrado.";
            } else if (!emailExists) {
                return "E-mail ou CPF inválidos.";
            } else {
                return "Senha incorreta.";
            }
        }
    }
    
    // Novo método para buscar a conta validada, se o login for bem-sucedido
    public Optional<Contas> getValidAccount(String cpf, String email, String senha) {
        List<Contas> contas = carregarContasDoJson();
        for (Contas conta : contas) {
            if (conta.getCpf().equals(cpf) &&
                conta.getEmail().equalsIgnoreCase(email) &&
                conta.verificarSenha(senha)) {
                return Optional.of(conta);
            }
        }
        return Optional.empty();
    }
}